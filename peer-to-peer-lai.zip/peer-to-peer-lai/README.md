# P2P Chat (Hybrid) - Java Swing + Socket

Ứng dụng chat theo mô hình P2P lai:
- Server chỉ quản lý đăng nhập/đăng xuất và phân phối danh sách peer đang online.
- Các peer kết nối trực tiếp (P2P) để chat cá nhân hoặc nhóm.
- Nếu server tắt sau khi có người dùng đã đăng nhập: những peer đang online vẫn chat và logout bình thường. (Không thể login mới khi server tắt.)

## Cấu trúc chính
- `src/main/java/org/example/server/ServerApp.java` – Hybrid login server, giao thức dạng dòng:
  - `LOGIN <username> <host> <port>` → `OK` + `LIST <n>` + n dòng `username host port`
  - `LOGOUT <username>` → `OK`
- `src/main/java/org/example/client/ClientApp.java` – Điểm vào ứng dụng client (khởi chạy UI Swing).
- `src/main/java/org/example/client/ChatUI.java` – Giao diện Swing: Login, danh sách peer (multi-select), khung chat, gửi tin, Logout.
- `src/main/java/org/example/client/ChatClient.java` – Logic mạng client: listener P2P, login/logout server, gửi/nhận tin nhắn giữa peer.
- `src/main/java/org/example/common/PeerInfo.java` – Mô tả thông tin một peer.

## Yêu cầu môi trường
- JDK 20 (có thể dùng JDK >= 17, khi đó chỉnh `pom.xml` `maven.compiler.source/target`).
- Maven (nếu bạn build/run bằng Maven). Nếu chưa cài Maven, bạn có thể chạy trực tiếp trong IntelliJ/IDEA.

## Build và Run

### Chạy bằng IDE (khuyên dùng nếu chưa cài Maven)
1. Mở project trong IntelliJ IDEA.
2. Chạy server:
   - Mở `src/main/java/org/example/server/ServerApp.java` → Run `main()`.
   - Server lắng nghe mặc định tại cổng `9090`.
3. Chạy nhiều client:
   - Mở `src/main/java/org/example/client/ClientApp.java` → Run `main()` nhiều lần để mở nhiều cửa sổ client.
   - Nhấn "Login" trong UI, nhập:
     - Server Host: `127.0.0.1` (hoặc IP của máy chạy server)
     - Server Port: `9090`
     - Username: tên duy nhất
     - Advertised Host: IP mà peer khác có thể kết nối tới (mặc định là IP cục bộ được gợi ý)
     - Listen Port: cổng P2P của client (mặc định `10000`, mỗi client nên khác cổng)
4. Chọn một hoặc nhiều peer ở danh sách bên trái, nhập nội dung và nhấn "Send" để chat nhóm/cá nhân.
5. Nhấn "Logout" để đăng xuất. Client sẽ báo cho server (nếu còn sống) và phát thông điệp `PRESENCE LOGOUT` tới các peer khác.

### Chạy bằng Maven (nếu đã cài Maven trong PATH)
```bash
mvn -DskipTests package
# Chạy server
mvn -Dexec.mainClass=org.example.server.ServerApp exec:java
# Chạy client (mở UI Swing)
mvn -Dexec.mainClass=org.example.client.ClientApp exec:java
```

Nếu bạn gặp lỗi `mvn: command not found` trên Windows, hãy:
- Cài đặt Maven và thêm vào PATH, hoặc
- Dùng cách chạy qua IDE như hướng dẫn ở trên.

## Ghi chú thiết kế
- Giao tiếp P2P qua TCP Socket, đóng khung tin nhắn dạng dòng đơn giản:
  - Từ peer gửi: `MSG <fromUsername> <message>` → peer nhận trả `OK`.
  - Thông báo hiện diện khi logout: `PRESENCE LOGOUT <username>`.
- Khi login thành công, server trả lại toàn bộ danh sách peer hiện tại. Danh sách này được lưu cục bộ để các peer chat trực tiếp.
- Khi server tắt:
  - Không thể login mới.
  - Peer đang online vẫn chat P2P và có thể logout (broadcast tới các peer khác) bình thường.

## Mở rộng tương lai
- Cập nhật danh sách peer theo thời gian thực (server push/broadcast hoặc long-polling).
- Bảo mật kênh P2P (TLS) và xác thực người dùng.
- Lưu lịch sử chat theo hội thoại.
- NAT traversal (STUN/TURN) nếu cần kết nối qua internet công cộng.
#   p 2 p - l a i  
 