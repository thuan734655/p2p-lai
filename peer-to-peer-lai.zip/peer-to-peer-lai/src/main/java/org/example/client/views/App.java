package org.example.client.views;

public class App {
    public static void main(String[] args) {
        new LoginView();
    }
}
